import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Filter, MapPin, Clock, Tag } from 'lucide-react-native';

const categories = [
  { id: 1, name: 'All', active: true },
  { id: 2, name: 'History', active: false },
  { id: 3, name: 'Culture', active: false },
  { id: 4, name: 'Nature', active: false },
  { id: 5, name: 'Local', active: false },
];

const stories = [
  {
    id: 1,
    title: 'The Ghost of Main Street',
    location: 'Downtown District',
    duration: '18 min',
    category: 'History',
    difficulty: 'Easy',
    description: 'Uncover the mysterious tales that haunt the historic main street.',
  },
  {
    id: 2,
    title: 'Riverside Legends',
    location: 'Riverside Park',
    duration: '22 min',
    category: 'Nature',
    difficulty: 'Moderate',
    description: 'Journey through ancient folklore along the winding river path.',
  },
  {
    id: 3,
    title: 'Art District Stories',
    location: 'Creative Quarter',
    duration: '14 min',
    category: 'Culture',
    difficulty: 'Easy',
    description: 'Discover the artists and creators who shaped this vibrant neighborhood.',
  },
  {
    id: 4,
    title: 'Hidden Speakeasy Tales',
    location: 'Historic Alley',
    duration: '16 min',
    category: 'History',
    difficulty: 'Moderate',
    description: 'Step back into the prohibition era and uncover secret establishments.',
  },
  {
    id: 5,
    title: 'Garden Sanctuary',
    location: 'Botanical Gardens',
    duration: '20 min',
    category: 'Nature',
    difficulty: 'Easy',
    description: 'Explore the peaceful stories hidden among ancient trees and flowers.',
  },
];

export default function ExploreScreen() {
  const [searchText, setSearchText] = useState('');
  const [selectedCategories, setSelectedCategories] = useState(categories);

  const handleCategoryPress = (categoryId: number) => {
    setSelectedCategories(prev =>
      prev.map(cat => ({
        ...cat,
        active: cat.id === 1 ? categoryId === 1 : cat.id === categoryId ? !cat.active : categoryId === 1 ? false : cat.active
      }))
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.title}>Explore Stories</Text>
          <View style={styles.searchContainer}>
            <Search size={20} color="#6B7280" style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search by location, category..."
              placeholderTextColor="#9CA3AF"
              value={searchText}
              onChangeText={setSearchText}
            />
            <TouchableOpacity style={styles.filterButton}>
              <Filter size={20} color="#4285F4" />
            </TouchableOpacity>
          </View>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoriesContainer}>
          {selectedCategories.map((category) => (
            <TouchableOpacity
              key={category.id}
              style={[styles.categoryButton, category.active && styles.activeCategoryButton]}
              onPress={() => handleCategoryPress(category.id)}
            >
              <Text style={[styles.categoryText, category.active && styles.activeCategoryText]}>
                {category.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{stories.length} stories found</Text>
          {stories.map((story) => (
            <TouchableOpacity key={story.id} style={styles.storyCard}>
              <View style={styles.storyHeader}>
                <View style={styles.storyInfo}>
                  <Text style={styles.storyTitle}>{story.title}</Text>
                  <View style={styles.storyMeta}>
                    <MapPin size={14} color="#0F7B6C" />
                    <Text style={styles.storyLocation}>{story.location}</Text>
                    <Text style={styles.metaDivider}>•</Text>
                    <Clock size={14} color="#6B7280" />
                    <Text style={styles.storyDuration}>{story.duration}</Text>
                  </View>
                  <Text style={styles.storyDescription}>{story.description}</Text>
                </View>
              </View>
              
              <View style={styles.storyFooter}>
                <View style={styles.storyTags}>
                  <View style={styles.categoryTag}>
                    <Tag size={12} color="#4285F4" />
                    <Text style={styles.categoryTagText}>{story.category}</Text>
                  </View>
                  <View style={[styles.difficultyTag, 
                    story.difficulty === 'Easy' ? styles.easyTag : styles.moderateTag
                  ]}>
                    <Text style={[styles.difficultyText,
                      story.difficulty === 'Easy' ? styles.easyText : styles.moderateText
                    ]}>
                      {story.difficulty}
                    </Text>
                  </View>
                </View>
                
                <TouchableOpacity style={styles.exploreButton}>
                  <Text style={styles.exploreButtonText}>Listen</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FFFE',
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 24,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1A1A1A',
  },
  filterButton: {
    padding: 4,
  },
  categoriesContainer: {
    paddingLeft: 24,
    marginBottom: 8,
  },
  categoryButton: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: 'white',
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeCategoryButton: {
    backgroundColor: '#4285F4',
    borderColor: '#4285F4',
  },
  categoryText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  activeCategoryText: {
    color: 'white',
  },
  section: {
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1A1A1A',
    marginBottom: 16,
  },
  storyCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  storyHeader: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  storyInfo: {
    flex: 1,
  },
  storyTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1A1A1A',
    marginBottom: 8,
  },
  storyMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  storyLocation: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#0F7B6C',
    marginLeft: 4,
    marginRight: 8,
  },
  metaDivider: {
    fontSize: 14,
    color: '#9CA3AF',
    marginRight: 8,
  },
  storyDuration: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginLeft: 4,
  },
  storyDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 20,
  },
  storyFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  storyTags: {
    flexDirection: 'row',
    flex: 1,
  },
  categoryTag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EBF4FF',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 8,
  },
  categoryTagText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#4285F4',
    marginLeft: 4,
  },
  difficultyTag: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  easyTag: {
    backgroundColor: '#ECFDF5',
  },
  moderateTag: {
    backgroundColor: '#FEF3C7',
  },
  difficultyText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
  },
  easyText: {
    color: '#059669',
  },
  moderateText: {
    color: '#D97706',
  },
  exploreButton: {
    backgroundColor: '#0F7B6C',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  exploreButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
});