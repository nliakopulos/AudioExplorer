import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, MapPin, Play, Clock, Star } from 'lucide-react-native';

const { width } = Dimensions.get('window');

const featuredStories = [
  {
    id: 1,
    title: 'Secrets of the Old Town',
    location: 'Historic District',
    duration: '12 min',
    rating: 4.8,
    image: 'https://images.pexels.com/photos/1838554/pexels-photo-1838554.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Discover hidden stories from centuries past',
  },
  {
    id: 2,
    title: 'Nature\'s Symphony',
    location: 'Central Park',
    duration: '8 min',
    rating: 4.9,
    image: 'https://images.pexels.com/photos/462024/pexels-photo-462024.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Listen to the sounds of nature and wildlife',
  },
];

const nearbyStories = [
  {
    id: 3,
    title: 'Coffee Shop Chronicles',
    location: '0.2 miles away',
    duration: '5 min',
    category: 'Local Stories',
  },
  {
    id: 4,
    title: 'Street Art Tales',
    location: '0.4 miles away',
    duration: '15 min',
    category: 'Culture',
  },
  {
    id: 5,
    title: 'Market Memories',
    location: '0.6 miles away',
    duration: '10 min',
    category: 'History',
  },
];

export default function HomeScreen() {
  const [searchText, setSearchText] = useState('');

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={styles.titleContainer}>
            <Text style={styles.logo}>AudioExplorer</Text>
            <Text style={styles.tagline}>A Hands-Free Experience for Your Journey</Text>
          </View>
          
          <View style={styles.searchContainer}>
            <Search size={20} color="#6B7280" style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search stories, locations..."
              placeholderTextColor="#9CA3AF"
              value={searchText}
              onChangeText={setSearchText}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Featured Stories</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.horizontalScroll}>
            {featuredStories.map((story) => (
              <TouchableOpacity key={story.id} style={styles.featuredCard}>
                <View style={styles.cardImagePlaceholder}>
                  <Play size={32} color="white" />
                </View>
                <View style={styles.cardContent}>
                  <Text style={styles.cardTitle}>{story.title}</Text>
                  <View style={styles.cardMeta}>
                    <MapPin size={14} color="#6B7280" />
                    <Text style={styles.cardLocation}>{story.location}</Text>
                  </View>
                  <View style={styles.cardFooter}>
                    <View style={styles.cardDuration}>
                      <Clock size={14} color="#6B7280" />
                      <Text style={styles.cardDurationText}>{story.duration}</Text>
                    </View>
                    <View style={styles.cardRating}>
                      <Star size={14} color="#FFA500" />
                      <Text style={styles.cardRatingText}>{story.rating}</Text>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Nearby Stories</Text>
          {nearbyStories.map((story) => (
            <TouchableOpacity key={story.id} style={styles.nearbyCard}>
              <View style={styles.nearbyCardContent}>
                <View style={styles.nearbyCardInfo}>
                  <Text style={styles.nearbyCardTitle}>{story.title}</Text>
                  <View style={styles.nearbyCardMeta}>
                    <MapPin size={14} color="#0F7B6C" />
                    <Text style={styles.nearbyCardLocation}>{story.location}</Text>
                    <Text style={styles.nearbyCardDivider}>•</Text>
                    <Clock size={14} color="#6B7280" />
                    <Text style={styles.nearbyCardDuration}>{story.duration}</Text>
                  </View>
                  <Text style={styles.nearbyCardCategory}>{story.category}</Text>
                </View>
                <TouchableOpacity style={styles.playButton}>
                  <Play size={20} color="#0F7B6C" strokeWidth={2} />
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FFFE',
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 24,
  },
  titleContainer: {
    marginBottom: 24,
  },
  logo: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  tagline: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#4285F4',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1A1A1A',
  },
  section: {
    marginTop: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1A1A1A',
    paddingHorizontal: 24,
    marginBottom: 16,
  },
  horizontalScroll: {
    paddingLeft: 24,
  },
  featuredCard: {
    width: width * 0.7,
    backgroundColor: 'white',
    borderRadius: 16,
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden',
  },
  cardImagePlaceholder: {
    height: 120,
    backgroundColor: '#0F7B6C',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    padding: 16,
  },
  cardTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1A1A1A',
    marginBottom: 8,
  },
  cardMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardLocation: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginLeft: 4,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cardDuration: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardDurationText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginLeft: 4,
  },
  cardRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardRatingText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1A1A1A',
    marginLeft: 4,
  },
  nearbyCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    marginHorizontal: 24,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  nearbyCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  nearbyCardInfo: {
    flex: 1,
  },
  nearbyCardTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1A1A1A',
    marginBottom: 6,
  },
  nearbyCardMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  nearbyCardLocation: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#0F7B6C',
    marginLeft: 4,
    marginRight: 8,
  },
  nearbyCardDivider: {
    fontSize: 14,
    color: '#9CA3AF',
    marginRight: 8,
  },
  nearbyCardDuration: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginLeft: 4,
  },
  nearbyCardCategory: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#4285F4',
    backgroundColor: '#EBF4FF',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
    alignSelf: 'flex-start',
  },
  playButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F0F9FF',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#0F7B6C',
  },
});