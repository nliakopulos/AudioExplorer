import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Slider, Dimensions, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Play, Pause, SkipBack, SkipForward, Volume2, Share, Heart, MapPin } from 'lucide-react-native';

const { width } = Dimensions.get('window');

export default function PlayerScreen() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [currentTime, setCurrentTime] = useState(180); // 3 minutes
  const [totalDuration] = useState(720); // 12 minutes
  const [volume, setVolume] = useState(0.8);
  const [scaleAnim] = useState(new Animated.Value(1));

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = currentTime / totalDuration;

  const handlePlayPress = () => {
    // Animate button press
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();

    setIsPlaying(!isPlaying);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Now Playing</Text>
        <TouchableOpacity style={styles.shareButton}>
          <Share size={20} color="#6B7280" />
        </TouchableOpacity>
      </View>

      <View style={styles.playerContainer}>
        <View style={styles.trackInfo}>
          <Text style={styles.trackTitle}>Secrets of the Old Town</Text>
          <View style={styles.trackMeta}>
            <MapPin size={16} color="#0F7B6C" />
            <Text style={styles.trackLocation}>Historic District</Text>
          </View>
          <Text style={styles.trackDescription}>
            Discover hidden stories from centuries past as you walk through the cobblestone streets.
          </Text>
        </View>

        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
            <View style={[styles.progressHandle, { left: `${progress * 100}%` }]} />
          </View>
          <View style={styles.timeContainer}>
            <Text style={styles.timeText}>{formatTime(currentTime)}</Text>
            <Text style={styles.timeText}>{formatTime(totalDuration)}</Text>
          </View>
        </View>

        <View style={styles.controls}>
          <TouchableOpacity style={styles.controlButton}>
            <SkipBack size={32} color="#6B7280" strokeWidth={1.5} />
          </TouchableOpacity>
          
          <Animated.View style={[{ transform: [{ scale: scaleAnim }] }]}>
            <TouchableOpacity 
              style={styles.playButton}
              onPress={handlePlayPress}
              activeOpacity={0.9}
            >
              <LinearGradient
                colors={['#4285F4', '#0F7B6C']}
                style={styles.playButtonGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <View style={styles.playButtonInner}>
                  {isPlaying ? (
                    <Pause size={40} color="white" strokeWidth={2} />
                  ) : (
                    <Play size={40} color="white" strokeWidth={2} />
                  )}
                </View>
              </LinearGradient>
            </TouchableOpacity>
          </Animated.View>
          
          <TouchableOpacity style={styles.controlButton}>
            <SkipForward size={32} color="#6B7280" strokeWidth={1.5} />
          </TouchableOpacity>
        </View>

        <View style={styles.secondaryControls}>
          <TouchableOpacity 
            style={styles.secondaryButton}
            onPress={() => setIsLiked(!isLiked)}
          >
            <Heart 
              size={24} 
              color={isLiked ? "#EF4444" : "#6B7280"} 
              fill={isLiked ? "#EF4444" : "none"}
              strokeWidth={1.5} 
            />
          </TouchableOpacity>
          
          <View style={styles.volumeContainer}>
            <Volume2 size={20} color="#6B7280" />
            <View style={styles.volumeSlider}>
              <View style={[styles.volumeFill, { width: `${volume * 100}%` }]} />
            </View>
          </View>
        </View>
      </View>

      <View style={styles.storyDetails}>
        <Text style={styles.sectionTitle}>Story Details</Text>
        <View style={styles.detailsGrid}>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Duration</Text>
            <Text style={styles.detailValue}>12 minutes</Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Category</Text>
            <Text style={styles.detailValue}>History</Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Difficulty</Text>
            <Text style={styles.detailValue}>Easy Walk</Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Rating</Text>
            <Text style={styles.detailValue}>4.8 ⭐</Text>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FFFE',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#1A1A1A',
  },
  shareButton: {
    padding: 8,
  },
  playerContainer: {
    flex: 1,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  trackInfo: {
    alignItems: 'center',
    marginBottom: 40,
  },
  trackTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1A1A1A',
    textAlign: 'center',
    marginBottom: 8,
  },
  trackMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  trackLocation: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#0F7B6C',
    marginLeft: 4,
  },
  trackDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 20,
    paddingHorizontal: 20,
  },
  progressContainer: {
    width: '100%',
    marginBottom: 40,
  },
  progressBar: {
    height: 4,
    backgroundColor: '#E5E7EB',
    borderRadius: 2,
    marginBottom: 8,
    position: 'relative',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#4285F4',
    borderRadius: 2,
  },
  progressHandle: {
    position: 'absolute',
    top: -6,
    width: 16,
    height: 16,
    backgroundColor: '#4285F4',
    borderRadius: 8,
    marginLeft: -8,
  },
  timeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  timeText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 32,
  },
  controlButton: {
    padding: 16,
  },
  playButton: {
    marginHorizontal: 32,
    shadowColor: '#4285F4',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 8,
  },
  playButtonGradient: {
    width: 88,
    height: 88,
    borderRadius: 44,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  playButtonInner: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  secondaryControls: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    justifyContent: 'space-between',
  },
  secondaryButton: {
    padding: 12,
  },
  volumeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    maxWidth: 120,
    marginLeft: 16,
  },
  volumeSlider: {
    flex: 1,
    height: 4,
    backgroundColor: '#E5E7EB',
    borderRadius: 2,
    marginLeft: 12,
  },
  volumeFill: {
    height: '100%',
    backgroundColor: '#0F7B6C',
    borderRadius: 2,
  },
  storyDetails: {
    paddingHorizontal: 24,
    paddingBottom: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1A1A1A',
    marginBottom: 16,
  },
  detailsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  detailItem: {
    width: '48%',
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  detailLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1A1A1A',
  },
});